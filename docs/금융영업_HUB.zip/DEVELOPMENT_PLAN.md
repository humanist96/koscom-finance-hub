# Securities Intelligence Hub - 상세 개발 계획서

## 1. 프로젝트 개요

### 1.1 목적
PowerBase 회원 증권사의 인사/사업 동향을 실시간 수집·요약하여 코스콤 금융영업부 직원의 영업활동을 지원하는 웹 애플리케이션

### 1.2 기술 스택
| 영역 | 기술 |
|------|------|
| Frontend | Next.js 15, TypeScript, Tailwind CSS v4, shadcn/ui |
| State Management | Zustand, TanStack Query |
| Backend | Next.js API Routes |
| Database | PostgreSQL (Prisma ORM) |
| Caching | Redis |
| 크롤링 | Puppeteer, Cheerio |
| AI 요약 | OpenAI GPT / Claude API |

---

## 2. 개발 단계별 계획

### Phase 1: MVP (최소 기능 제품) - 핵심 기능

#### Sprint 1: 기반 구축 (Week 1)
- [x] 프로젝트 초기 설정
- [x] 폴더 구조 및 타입 정의
- [x] Prisma 스키마 설계
- [ ] Docker 환경 구성 (PostgreSQL, Redis)
- [ ] 시드 데이터 작성 (증권사 목록)

#### Sprint 2: 백엔드 API (Week 2)
- [ ] API 라우트 구현
  - GET /api/companies - 증권사 목록
  - GET /api/news - 뉴스 목록 (필터링, 페이지네이션)
  - GET /api/news/[id] - 뉴스 상세
  - GET /api/personnel - 인사 정보 목록
  - GET /api/search - 통합 검색
- [ ] 에러 핸들링 미들웨어
- [ ] API 응답 표준화

#### Sprint 3: 크롤링 시스템 (Week 2-3)
- [ ] 크롤러 기본 구조 설계
- [ ] 증권사별 뉴스룸 크롤러 구현
  - 삼성증권, 미래에셋, NH투자증권 등
- [ ] 네이버 뉴스 API 연동
- [ ] 인사 정보 파싱 로직
- [ ] 스케줄러 구현 (daily cron)

#### Sprint 4: 프론트엔드 UI (Week 3-4)
- [ ] 레이아웃 컴포넌트
  - Header (로고, 검색, 네비게이션)
  - Sidebar (증권사 필터)
  - Main Content Area
- [ ] 뉴스 목록 페이지
  - 카드형 뉴스 리스트
  - 필터링 (증권사, 카테고리, 기간)
  - 무한 스크롤 / 페이지네이션
- [ ] 뉴스 상세 모달/페이지
- [ ] 인사 정보 페이지
  - 타임라인 뷰
  - 인사 변동 유형별 필터
- [ ] 검색 기능
- [ ] 반응형 모바일 UI

#### Sprint 5: AI 요약 기능 (Week 4)
- [ ] AI 요약 API 연동 (OpenAI/Claude)
- [ ] 개별 뉴스 요약
- [ ] 프롬프트 최적화

---

### Phase 2: 확장 기능

#### Sprint 6: 사용자 기능 (Week 5)
- [ ] 사용자 인증 (SSO 또는 간단 로그인)
- [ ] 관심 증권사 즐겨찾기
- [ ] 키워드 알림 설정

#### Sprint 7: 리포트 기능 (Week 6)
- [ ] 주간 리포트 자동 생성
- [ ] 데이터 내보내기 (Excel, PDF)
- [ ] 대시보드 통계

---

## 3. 상세 기능 명세

### 3.1 뉴스 목록 페이지 (`/`)

```
┌────────────────────────────────────────────────────────────┐
│  Securities Intelligence Hub              🔍 검색...  [👤] │
├─────────────┬──────────────────────────────────────────────┤
│ 증권사 필터  │  📰 최근 뉴스                    [기간 ▼]   │
│             │                                              │
│ ☑ 전체      │  ┌────────────────────────────────────────┐ │
│ ☐ 삼성증권  │  │ 🏢 삼성증권                   2시간 전  │ │
│ ☐ 미래에셋  │  │ 삼성증권, 신규 WM 서비스 출시          │ │
│ ☐ NH투자   │  │ [상품] AI 기반 자산관리 서비스...       │ │
│ ...        │  │ 📝 AI 요약 | 🔗 원문보기              │ │
│             │  └────────────────────────────────────────┘ │
│ 카테고리    │                                              │
│ ☑ 전체     │  ┌────────────────────────────────────────┐ │
│ ☐ 인사     │  │ 🏢 미래에셋증권               어제     │ │
│ ☐ 사업     │  │ [인사] 2024년 상반기 임원 인사         │ │
│ ☐ 상품     │  │ 홍길동 부사장 → 대표이사 승진...       │ │
│             │  └────────────────────────────────────────┘ │
└─────────────┴──────────────────────────────────────────────┘
```

### 3.2 인사 정보 페이지 (`/personnel`)

```
┌────────────────────────────────────────────────────────────┐
│  👔 인사 동향                              [기간 ▼] [유형 ▼]│
├────────────────────────────────────────────────────────────┤
│                                                            │
│  2024.01.15  ─────────────────────────────────────────     │
│  │                                                         │
│  │  🔵 [삼성증권] 홍길동 - 대표이사 신규 임명              │
│  │     이전: 부사장 (리테일사업부)                         │
│  │                                                         │
│  │  🟢 [NH투자증권] 김철수 - 본부장 승진                   │
│  │     WM사업본부                                          │
│  │                                                         │
│  2024.01.10  ─────────────────────────────────────────     │
│  │                                                         │
│  │  🟡 [미래에셋] 이영희 - 지점장 전보                     │
│  │     강남지점 → 분당지점                                 │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### 3.3 증권사 상세 페이지 (`/companies/[id]`)

```
┌────────────────────────────────────────────────────────────┐
│  ← 뒤로  삼성증권                              ⭐ 즐겨찾기  │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  [로고]  삼성증권                                          │
│          www.samsungpop.com                                │
│                                                            │
│  ────────────────────────────────────────────────────────  │
│                                                            │
│  📊 최근 1주 요약                                          │
│  ┌────────────────────────────────────────────────────┐   │
│  │ • 신규 AI 자산관리 서비스 'S-Wealth' 출시           │   │
│  │ • 2024년 1분기 실적 발표 예정                       │   │
│  │ • 리테일사업부 조직개편                             │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  [뉴스] [인사] [통계]                                      │
│  ──────────────────────────────────────────────           │
│  최근 뉴스 목록...                                         │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

## 4. API 명세

### 4.1 뉴스 API

#### GET /api/news
뉴스 목록 조회

**Query Parameters:**
| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|------|------|
| page | number | N | 페이지 번호 (default: 1) |
| limit | number | N | 페이지당 항목 수 (default: 20) |
| companyIds | string | N | 증권사 ID (콤마 구분) |
| categories | string | N | 카테고리 (콤마 구분) |
| isPersonnel | boolean | N | 인사 뉴스만 조회 |
| startDate | string | N | 시작일 (YYYY-MM-DD) |
| endDate | string | N | 종료일 (YYYY-MM-DD) |
| keyword | string | N | 검색 키워드 |

**Response:**
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "clx...",
        "title": "삼성증권, 신규 서비스 출시",
        "summary": "AI 기반 자산관리...",
        "sourceUrl": "https://...",
        "sourceName": "삼성증권 뉴스룸",
        "category": "PRODUCT",
        "isPersonnel": false,
        "publishedAt": "2024-01-15T09:00:00Z",
        "company": {
          "id": "clx...",
          "name": "삼성증권",
          "logoUrl": "..."
        }
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "totalPages": 8,
      "hasMore": true
    }
  }
}
```

#### GET /api/news/[id]
뉴스 상세 조회

#### POST /api/news/summarize
뉴스 AI 요약 요청

---

### 4.2 증권사 API

#### GET /api/companies
증권사 목록 조회

#### GET /api/companies/[id]
증권사 상세 조회 (최근 뉴스, 인사 정보 포함)

---

### 4.3 인사 정보 API

#### GET /api/personnel
인사 정보 목록 조회

---

### 4.4 검색 API

#### GET /api/search
통합 검색 (뉴스 + 인사 정보)

---

## 5. 데이터베이스 스키마

```
┌─────────────────────┐       ┌─────────────────────┐
│ SecuritiesCompany   │       │ News                │
├─────────────────────┤       ├─────────────────────┤
│ id (PK)             │───┐   │ id (PK)             │
│ name                │   │   │ companyId (FK)      │←─┐
│ code                │   │   │ title               │  │
│ logoUrl             │   │   │ content             │  │
│ websiteUrl          │   │   │ summary             │  │
│ newsroomUrl         │   └──→│ sourceUrl           │  │
│ isActive            │       │ category            │  │
│ createdAt           │       │ isPersonnel         │  │
│ updatedAt           │       │ publishedAt         │  │
└─────────────────────┘       └─────────────────────┘  │
         │                                              │
         │            ┌─────────────────────┐          │
         │            │ PersonnelChange     │          │
         │            ├─────────────────────┤          │
         └───────────→│ id (PK)             │          │
                      │ companyId (FK)      │──────────┘
                      │ personName          │
                      │ position            │
                      │ changeType          │
                      │ effectiveDate       │
                      │ announcedAt         │
                      └─────────────────────┘
```

---

## 6. 크롤링 전략

### 6.1 데이터 소스

| 소스 | URL 패턴 | 수집 주기 | 우선순위 |
|------|----------|----------|---------|
| 삼성증권 뉴스룸 | samsungpop.com/newsroom | 1일 | 높음 |
| 미래에셋 보도자료 | miraeasset.com/press | 1일 | 높음 |
| NH투자 뉴스 | nhqv.com/news | 1일 | 높음 |
| 네이버 뉴스 | openapi.naver.com | 6시간 | 높음 |
| 연합인포맥스 | yonhapinfomax.com | 6시간 | 중간 |

### 6.2 크롤러 아키텍처

```
┌─────────────────────────────────────────────────────────────┐
│                      Scheduler (Cron)                       │
│                    - 매일 오전 7시 실행                      │
│                    - 6시간 간격 뉴스 API 호출                 │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    Crawler Manager                          │
│                - 동시 실행 제한 (5개)                        │
│                - 재시도 로직                                 │
│                - 로깅                                        │
└─────────────────────────┬───────────────────────────────────┘
                          │
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│ Site Crawler    │ │ Site Crawler    │ │ News API        │
│ (Puppeteer)     │ │ (Cheerio)       │ │ (Naver)         │
└────────┬────────┘ └────────┬────────┘ └────────┬────────┘
         │                   │                   │
         └───────────────────┼───────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    Data Processor                           │
│              - 중복 검사                                     │
│              - 카테고리 분류 (AI)                            │
│              - 인사 정보 추출                                │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    Database (PostgreSQL)                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 7. 폴더 구조

```
securities-intelligence-hub/
├── docs/                          # 문서
│   └── DEVELOPMENT_PLAN.md
├── prisma/                        # 데이터베이스
│   ├── schema.prisma
│   └── seed.ts
├── scripts/                       # 스크립트
│   └── crawlers/                  # 크롤러
│       ├── base-crawler.ts
│       ├── samsung-crawler.ts
│       ├── mirae-crawler.ts
│       └── naver-news-crawler.ts
├── src/
│   ├── app/                       # Next.js App Router
│   │   ├── layout.tsx
│   │   ├── page.tsx               # 메인 (뉴스 목록)
│   │   ├── personnel/
│   │   │   └── page.tsx           # 인사 정보
│   │   ├── companies/
│   │   │   └── [id]/
│   │   │       └── page.tsx       # 증권사 상세
│   │   └── api/                   # API Routes
│   │       ├── news/
│   │       ├── companies/
│   │       ├── personnel/
│   │       ├── search/
│   │       └── crawl/
│   ├── components/
│   │   ├── ui/                    # shadcn/ui 컴포넌트
│   │   ├── layout/                # 레이아웃 컴포넌트
│   │   │   ├── header.tsx
│   │   │   ├── sidebar.tsx
│   │   │   └── mobile-nav.tsx
│   │   └── features/              # 기능별 컴포넌트
│   │       ├── news/
│   │       │   ├── news-card.tsx
│   │       │   ├── news-list.tsx
│   │       │   └── news-filter.tsx
│   │       └── personnel/
│   │           ├── personnel-item.tsx
│   │           └── personnel-timeline.tsx
│   ├── hooks/                     # 커스텀 훅
│   │   ├── use-news.ts
│   │   ├── use-companies.ts
│   │   └── use-debounce.ts
│   ├── lib/                       # 유틸리티
│   │   ├── prisma.ts
│   │   ├── utils.ts
│   │   └── query-client.ts
│   ├── services/                  # API 서비스
│   │   ├── news-service.ts
│   │   ├── company-service.ts
│   │   └── ai-service.ts
│   ├── stores/                    # 상태 관리
│   │   └── filter-store.ts
│   ├── types/                     # 타입 정의
│   │   ├── index.ts
│   │   ├── news.ts
│   │   ├── company.ts
│   │   └── api.ts
│   └── constants/                 # 상수
│       └── index.ts
├── .env.example
├── .env.local
├── package.json
└── README.md
```

---

## 8. 개발 우선순위 및 권장 순서

### 추천 개발 순서

1. **데이터베이스 설정** (선행 필수)
   - Docker로 PostgreSQL 실행
   - Prisma migrate 실행
   - 시드 데이터 입력

2. **백엔드 API 개발**
   - 증권사 목록 API
   - 뉴스 목록/상세 API
   - 인사 정보 API

3. **크롤링 시스템** (백엔드와 병행 가능)
   - 기본 크롤러 구조
   - 1-2개 증권사 크롤러 테스트
   - 네이버 뉴스 API 연동

4. **프론트엔드 UI**
   - 레이아웃 구조
   - 뉴스 목록 페이지
   - 필터링 기능
   - 인사 정보 페이지

5. **AI 요약 기능**
   - API 연동
   - 프롬프트 최적화

---

## 9. 환경 설정 가이드

### 9.1 개발 환경 실행

```bash
# 1. 의존성 설치
npm install

# 2. 환경 변수 설정
cp .env.example .env.local
# .env.local 파일 편집

# 3. Docker로 DB 실행
docker-compose up -d

# 4. Prisma 마이그레이션
npx prisma migrate dev

# 5. 시드 데이터 입력
npx prisma db seed

# 6. 개발 서버 실행
npm run dev
```

### 9.2 Docker Compose 설정

```yaml
# docker-compose.yml
version: '3.8'
services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
      POSTGRES_DB: securities_hub
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

---

## 10. 다음 단계

워크스페이스가 준비되었습니다. 다음 중 어떤 것을 먼저 진행할지 선택해주세요:

1. **Docker 환경 구성** - PostgreSQL, Redis 컨테이너 설정
2. **시드 데이터 작성** - 증권사 목록 초기 데이터
3. **백엔드 API 개발** - 뉴스/증권사/인사 API
4. **크롤러 개발** - 데이터 수집 시스템
5. **프론트엔드 UI** - 레이아웃 및 페이지 컴포넌트
